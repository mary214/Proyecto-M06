<template>
    <h1>Estos son nuestros contactos</h1>
       
    
</template>

<script>
export default {
  name: 'PContacto', // Asegúrate de que el nombre coincida
};
</script>